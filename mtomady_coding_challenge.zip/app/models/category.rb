class Category < ActiveRecord::Base
    belongs_to :treatment
end
